import pika
from config import *
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RabbitMQConnectionManager:
    _instance = None
    _connection = None
    _channel = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(RabbitMQConnectionManager, cls).__new__(cls)
        return cls._instance

    def get_connection(self):
        if not self._connection or self._connection.is_closed:
            try:
                credentials = pika.PlainCredentials(RABBITMQ_USER, RABBITMQ_PASSWORD)
                parameters = pika.ConnectionParameters(
                    host=RABBITMQ_HOST,
                    port=RABBITMQ_PORT,
                    credentials=credentials,
                    heartbeat=600,
                    blocked_connection_timeout=300
                )
                self._connection = pika.BlockingConnection(parameters)
                logger.info("Created new RabbitMQ connection")
            except Exception as e:
                logger.error(f"Failed to create RabbitMQ connection: {str(e)}")
                raise
        return self._connection

    def get_channel(self):
        if not self._channel or self._channel.is_closed:
            try:
                self._channel = self.get_connection().channel()
                self._channel.confirm_delivery()
                logger.info("Created new RabbitMQ channel")
            except Exception as e:
                logger.error(f"Failed to create RabbitMQ channel: {str(e)}")
                raise
        return self._channel

    def close(self):
        try:
            if self._channel and not self._channel.is_closed:
                self._channel.close()
            if self._connection and not self._connection.is_closed:
                self._connection.close()
            logger.info("Closed RabbitMQ connection and channel")
        except Exception as e:
            logger.error(f"Error closing RabbitMQ connection: {str(e)}")
            raise 