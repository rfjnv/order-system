import pika
import json
import time
import random
import logging
from config import *
from connection_manager import RabbitMQConnectionManager

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

def process_delivery(ch, method, properties, body):
    try:
        delivery = json.loads(body)
        order_id = delivery['order_id']
        
        # Get retry count from message headers
        retry_count = properties.headers.get('retry_count', 0) if properties.headers else 0
        
        logger.info(f"🚚 Delivery service received order {order_id} (attempt {retry_count + 1})")
        
        # Simulate delivery guy approaching restaurant
        time.sleep(2)
        
        # Simulate random availability (80% chance of success)
        if random.random() < 0.8:
            logger.info(f"📍 Delivery person is nearby and ready to pick up order {order_id}")
            logger.info(f"Order {order_id} has been picked up and is being delivered")
            
            # Simulate delivery time
            time.sleep(3)
            logger.info(f"✅ Order {order_id} has been delivered successfully!")
            
            # Acknowledge the message
            ch.basic_ack(delivery_tag=method.delivery_tag)
        else:
            if retry_count < MAX_RETRIES:
                logger.warning(f"Delivery guy is not available for order {order_id}, will retry...")
                
                # Reject the message and requeue with updated retry count
                ch.basic_nack(
                    delivery_tag=method.delivery_tag,
                    requeue=True,
                    properties=pika.BasicProperties(
                        headers={'retry_count': retry_count + 1}
                    )
                )
                time.sleep(RETRY_DELAY)
            else:
                logger.error(f"Order {order_id} failed after {MAX_RETRIES} attempts")
                # Reject without requeue after max retries
                ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
                
    except json.JSONDecodeError as e:
        logger.error(f"Failed to decode delivery message: {str(e)}")
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
    except pika.exceptions.AMQPConnectionError as e:
        logger.error(f"Failed to connect to RabbitMQ: {str(e)}")
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
    except Exception as e:
        logger.error(f"Error processing delivery: {str(e)}")
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)

def main():
    manager = RabbitMQConnectionManager()
    
    try:
        channel = manager.get_channel()
        
        # Declare queue with durability
        channel.queue_declare(queue=DELIVERY_QUEUE, durable=True)
        
        # Set prefetch count
        channel.basic_qos(prefetch_count=1)
        
        logger.info("Delivery service is ready to process orders...")
        
        # Start consuming
        channel.basic_consume(
            queue=DELIVERY_QUEUE,
            on_message_callback=process_delivery
        )
        
        channel.start_consuming()
        
    except KeyboardInterrupt:
        logger.info("Delivery service stopped by user")
    except Exception as e:
        logger.error(f"Error in delivery service: {str(e)}")
    finally:
        manager.close()

if __name__ == "__main__":
    main()