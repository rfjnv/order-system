import pika
import json
import time
import logging
from config import *
from connection_manager import RabbitMQConnectionManager

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

def send_notification(ch, method, properties, body):
    try:
        notification = json.loads(body)
        order_id = notification['order_id']
        
        logger.info(f"Processing notification for order {order_id}")
        
        # Simulate sending notification to customer
        notify_customer(order_id)
        
        # Send message to delivery queue
        channel = ch.connection.channel()
        channel.queue_declare(queue=DELIVERY_QUEUE, durable=True)
        
        delivery_message = {
            'order_id': order_id,
            'status': 'ready_for_delivery',
            'items': notification['items']
        }
        
        channel.basic_publish(
            exchange='',
            routing_key=DELIVERY_QUEUE,
            body=json.dumps(delivery_message),
            properties=pika.BasicProperties(
                delivery_mode=2,
                content_type='application/json'
            ),
            mandatory=True
        )
        
        logger.info(f"Delivery service notified about order {order_id}")
        
        # Acknowledge the message
        ch.basic_ack(delivery_tag=method.delivery_tag)
        
    except json.JSONDecodeError as e:
        logger.error(f"Failed to decode notification message: {str(e)}")
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
    except pika.exceptions.AMQPConnectionError as e:
        logger.error(f"Failed to connect to RabbitMQ: {str(e)}")
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
    except Exception as e:
        logger.error(f"Error processing notification: {str(e)}")
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)

def notify_customer(order_id):
    """Simulate notifying the customer."""
    try:
        logger.info(f"📩 Notification service: Sending notification for order {order_id}.")
        logger.info(f"✅ Customer has been notified about order {order_id}.")
    except Exception as e:
        logger.error(f"❌ Failed to notify customer for order {order_id}: {str(e)}")

def main():
    manager = RabbitMQConnectionManager()
    
    try:
        channel = manager.get_channel()
        
        # Declare queues with durability
        channel.queue_declare(queue=NOTIFICATION_QUEUE, durable=True)
        channel.queue_declare(queue=DELIVERY_QUEUE, durable=True)
        
        # Set prefetch count
        channel.basic_qos(prefetch_count=1)
        
        logger.info("Notification service is ready to process messages...")
        
        # Start consuming
        channel.basic_consume(
            queue=NOTIFICATION_QUEUE,
            on_message_callback=send_notification
        )
        
        channel.start_consuming()
        
    except KeyboardInterrupt:
        logger.info("Notification service stopped by user")
    except Exception as e:
        logger.error(f"Error in notification service: {str(e)}")
    finally:
        manager.close()

if __name__ == "__main__":
    main()