import json
import time
import logging
import pika
from config import *
from connection_manager import RabbitMQConnectionManager

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Define the menu with categories
MENU = {
    "Dishes": {
        1: "Pizza",
        2: "Burger",
        3: "Pasta",
        4: "Salad"
    },
    "Drinks": {
        5: "Coke",
        6: "Water",
        7: "Juice",
        8: "Coffee"
    },
    "Desserts": {
        9: "Ice Cream",
        10: "Cake",
        11: "Brownie"
    }
}

def display_menu(category=None):
    """Display the menu to the user."""
    print("\n--- Menu ---")
    if category:
        print(f"\n{category}:")
        for number, item in enumerate(MENU[category].values(), start=1):
            print(f"{number}. {item}")
        print("0. Back to Categories")
    else:
        item_number = 1
        all_items = {}
        for category, items in MENU.items():
            print(f"\n{category}:")
            for item in items.values():
                print(f"  {item_number}. {item}")
                all_items[item_number] = item
                item_number += 1
        print("\n")
        return all_items

def place_order(order_id, items):
    """Send the order to RabbitMQ."""
    manager = RabbitMQConnectionManager()
    channel = manager.get_channel()
    
    try:
        # Declare the chef queue with durability
        channel.queue_declare(queue=CHEF_QUEUE, durable=True)
        
        # Create order message
        order = {
            'order_id': order_id,
            'items': items,
            'timestamp': time.time()
        }
        
        # Publish the order to chef queue with confirmation
        channel.basic_publish(
            exchange='',
            routing_key=CHEF_QUEUE,
            body=json.dumps(order),
            properties=pika.BasicProperties(
                delivery_mode=2,  # make message persistent
                content_type='application/json'
            ),
            mandatory=True
        )
        
        logger.info(f"✅ Order {order_id} has been placed successfully! Items: {', '.join(items)}")
        
    except pika.exceptions.AMQPConnectionError as e:
        logger.error(f"❌ Failed to connect to RabbitMQ: {str(e)}")
        raise
    except pika.exceptions.AMQPChannelError as e:
        logger.error(f"❌ Channel error: {str(e)}")
        raise
    except Exception as e:
        logger.error(f"❌ Unexpected error while placing order: {str(e)}")
        raise

def main():
    """Main function to handle the order creation process."""
    try:
        while True:
            print("\nWelcome to the Order System!")
            
            # Ask for order ID first
            order_id = input("Enter your order ID: ").strip()
            if not order_id:
                print("Order ID cannot be empty. Please try again.")
                continue
            
            items = []
            
            while True:
                print("\nChoose a category:")
                print("1. Dishes")
                print("2. Drinks")
                print("3. Desserts")
                print("0. All Menu")
                
                category_choice = input("Enter your choice (0-3): ").strip()
                
                if category_choice == "1":
                    while True:
                        display_menu("Dishes")
                        item_choice = input("Enter the item number or '0' to go back: ").strip()
                        if item_choice == "0":
                            break  # Go back to the main category selection
                        elif item_choice.isdigit() and 1 <= int(item_choice) <= len(MENU["Dishes"]):
                            items.append(list(MENU["Dishes"].values())[int(item_choice) - 1])
                            print(f"Added: {list(MENU['Dishes'].values())[int(item_choice) - 1]}")
                        else:
                            print("Invalid choice. Please try again.")
                elif category_choice == "2":
                    while True:
                        display_menu("Drinks")
                        item_choice = input("Enter the item number or '0' to go back: ").strip()
                        if item_choice == "0":
                            break  # Go back to the main category selection
                        elif item_choice.isdigit() and 1 <= int(item_choice) <= len(MENU["Drinks"]):
                            items.append(list(MENU["Drinks"].values())[int(item_choice) - 1])
                            print(f"Added: {list(MENU['Drinks'].values())[int(item_choice) - 1]}")
                        else:
                            print("Invalid choice. Please try again.")
                elif category_choice == "3":
                    while True:
                        display_menu("Desserts")
                        item_choice = input("Enter the item number or '0' to go back: ").strip()
                        if item_choice == "0":
                            break  # Go back to the main category selection
                        elif item_choice.isdigit() and 1 <= int(item_choice) <= len(MENU["Desserts"]):
                            items.append(list(MENU["Desserts"].values())[int(item_choice) - 1])
                            print(f"Added: {list(MENU['Desserts'].values())[int(item_choice) - 1]}")
                        else:
                            print("Invalid choice. Please try again.")
                elif category_choice == "0":
                    all_items = display_menu()
                    while True:
                        item_choice = input("Enter the item number or 'done' to finalize your order: ").strip()
                        if item_choice.lower() == "done":
                            break
                        elif item_choice.isdigit() and int(item_choice) in all_items:
                            items.append(all_items[int(item_choice)])
                            print(f"Added: {all_items[int(item_choice)]}")
                        else:
                            print("Invalid choice. Please try again.")
                else:
                    print("Invalid choice. Please try again.")
                    continue
                
                # Check if the user wants to finalize the order
                if items:
                    finalize = input("Do you want to finalize your order? (yes/no): ").strip().lower()
                    if finalize == "yes":
                        break
            
            if not items:
                print("No items selected. Please try again.")
                continue
            
            place_order(order_id, items)
            
            another = input("Do you want to place another order? (yes/no): ").strip().lower()
            if another != 'yes':
                print("Thank you for using the Order System!")
                break
            
    except KeyboardInterrupt:
        logger.info("⚠️ Order creator stopped by user.")
    except Exception as e:
        logger.error(f"❌ Error in order creator: {str(e)}")
    finally:
        RabbitMQConnectionManager().close()

if __name__ == "__main__":
    main()