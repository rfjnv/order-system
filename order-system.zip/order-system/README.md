# Restaurant Order Processing Simulation

This project simulates a restaurant order processing system using RabbitMQ for message queuing. The system consists of four main components:

1. Order Creator - Places orders and sends them to the chef queue
2. Chef Service - Processes orders and notifies customers
3. Notification Service - Handles customer notifications and triggers delivery
4. Delivery Service - Manages order delivery with retry mechanism

## Prerequisites

- Python 3.7+
- RabbitMQ server running locally
- pip (Python package manager)

## Installation

1. Install the required dependencies:

```bash
pip install -r requirements.txt
```

2. Make sure RabbitMQ is running on your local machine (default port: 5672)

## Running the Simulation

1. Start the services in separate terminal windows:

```bash
# Terminal 1 - Chef Service
python chef_service.py

# Terminal 2 - Notification Service
python notification_service.py

# Terminal 3 - Delivery Service
python delivery_service.py

# Terminal 4 - Order Creator (after other services are running)
python order_creator.py
```

## Features

- Asynchronous order processing using RabbitMQ queues
- Message acknowledgments for reliable delivery
- Retry mechanism for delivery service
- Persistent messages to prevent data loss
- Simulated delays to mimic real-world scenarios

## Queue Structure

- `chef_queue`: Receives new orders
- `notification_queue`: Handles customer notifications
- `delivery_queue`: Manages delivery assignments

## Error Handling

- The delivery service includes a retry mechanism (80% success rate)
- Messages are persisted to prevent data loss
- Services use acknowledgments to ensure message processing
