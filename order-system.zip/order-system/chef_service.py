import pika
import json
import time
import logging
from config import *
from connection_manager import RabbitMQConnectionManager

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

def process_order(ch, method, properties, body):
    try:
        order = json.loads(body)
        order_id = order['order_id']
        
        logger.info(f"👨‍🍳 Chef received order {order_id}.")
        logger.info(f"Cooking items: {', '.join(order['items'])}")
        
        # Simulate cooking time
        time.sleep(5)
        
        # Send notification to customer
        channel = ch.connection.channel()
        channel.queue_declare(queue=NOTIFICATION_QUEUE, durable=True)
        
        notification = {
            'order_id': order_id,
            'status': 'cooking',
            'items': order['items']
        }
        
        channel.basic_publish(
            exchange='',
            routing_key=NOTIFICATION_QUEUE,
            body=json.dumps(notification),
            properties=pika.BasicProperties(
                delivery_mode=2,
                content_type='application/json'
            ),
            mandatory=True
        )
        
        logger.info(f"✅ Order {order_id} has been prepared and is ready for delivery.")
        
        # Acknowledge the message
        ch.basic_ack(delivery_tag=method.delivery_tag)
        
    except json.JSONDecodeError as e:
        logger.error(f"❌ Failed to decode order message: {str(e)}")
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
    except pika.exceptions.AMQPConnectionError as e:
        logger.error(f"❌ Failed to connect to RabbitMQ: {str(e)}")
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)
    except Exception as e:
        logger.error(f"❌ Error processing order {order_id}: {str(e)}")
        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=True)

def main():
    manager = RabbitMQConnectionManager()
    
    try:
        channel = manager.get_channel()
        
        # Declare queues with durability
        channel.queue_declare(queue=CHEF_QUEUE, durable=True)
        channel.queue_declare(queue=NOTIFICATION_QUEUE, durable=True)
        
        # Set prefetch count
        channel.basic_qos(prefetch_count=1)
        
        logger.info("Chef service is ready to process orders...")
        
        # Start consuming
        channel.basic_consume(
            queue=CHEF_QUEUE,
            on_message_callback=process_order
        )
        
        channel.start_consuming()
        
    except KeyboardInterrupt:
        logger.info("Chef service stopped by user")
    except Exception as e:
        logger.error(f"Error in chef service: {str(e)}")
    finally:
        manager.close()

if __name__ == "__main__":
    main()