import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# RabbitMQ connection settings
RABBITMQ_HOST = os.getenv('RABBITMQ_HOST', 'localhost')
RABBITMQ_PORT = int(os.getenv('RABBITMQ_PORT', 5672))
RABBITMQ_USER = os.getenv('RABBITMQ_USER', 'guest')
RABBITMQ_PASSWORD = os.getenv('RABBITMQ_PASSWORD', 'guest')

# Queue names
CHEF_QUEUE = 'chef_queue'
NOTIFICATION_QUEUE = 'notification_queue'
DELIVERY_QUEUE = 'delivery_queue'

# Retry settings
MAX_RETRIES = 3
RETRY_DELAY = 5  # seconds 